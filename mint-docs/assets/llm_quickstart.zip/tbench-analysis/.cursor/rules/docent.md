---
alwaysApply: true
---

# Docent Analysis Guide

Docent is a platform for analyzing AI agent behavior using large language models. It offers a Python SDK to configure and submit analysis jobs.

General notes:
* If the user asks you to "summarize the agent runs", "classify the results", or similar, they do not necessarily mean that you (the coding agent) should do so directly. In most cases, it is better to use the Docent SDK to submit an LLM analysis request. Then you may open the results of that analysis to show the user.
* Agent runs contain metadata. Metadata varies by collection. Do not make assumptions about the structure of run metadata. Use the `get_metadata_fields` MCP tool to find out.
* If you are writing code that will submit LLMRequests, you are encouraged to write it out as a script so you can improve and re-use it later. Unless otherwise instructed, you may place analysis scripts in the current working directory. Quick DQL queries can be done in scripts or inline with the Bash tool at your discretion.
* If you're not sure what collection the user is talking about, check the DOCENT_COLLECTION_ID env var and the docent.env file if available. If you can't find a collection ID, ask the user for it.
* Make sure you understand exactly what the user is asking you to do. If their request is ambiguous, use AskUserQuestion tool to clarify. Don't make assumptions.

Start with these imports when using the Docent SDK:
```python
from docent.sdk.client import Docent
from docent.sdk.llm_request import LLMRequest, LLMResult
from docent.sdk.llm_context import Prompt, AgentRunRef, ResultRef

client = Docent()
```

* When writing code to perform analysis, Don't Repeat Yourself. This is particularly important when it comes to prompts for LLMs. The user will likely want to modify prompts, and they should not have to track down multiple copies of a prompt throughout your code. If you need to create different variants of a prompt, build them from reusable pieces and/or use string interpolation, so there is a single source of truth for each part of the prompt.
* When writing code to perform analysis, keep variable names generic. For example, if you are comparing the performance of two models, you might refer to them as "model_a" and "model_b" in your code, and then declare the identity of these models in one place only. This makes your code more reusable, so we can perform the same analysis on other data.
* When writing code to perform analysis, be sparing with print statements. In many cases a simple success/failure message at the end is enough.

## Notes on methodology
If you are analyzing a limited sample of many items (e.g. because you can only fit so many in the context window), be mindful of *how* you are sampling them. The most recent N items may be a biased sample. It is safe to assume that UUIDs are random.

Always keep the user informed of *how* you are doing your analysis, whether that's by proposing a plan before you write code, or presenting your results afterward. Be clear about what context items are being passed to the LLM at each step of your analysis, and how those context items are selected.

If you design and execute any analysis independently of the user, communicate clearly what you did. For example, if you say "60% of the runs contained syntax errors", you should also explain your methodology for deciding what is a syntax error.

## Building LLMRequests with the Prompt API

The `Prompt` class takes a list of refs and strings. Refs are lightweight references to agent runs, transcripts, or analysis results—you do NOT need to fetch the full content.

```python
# Create refs for agent runs
run = AgentRunRef(id="<agent-run-uuid>", collection_id="<collection-uuid>")

request = LLMRequest(
    prompt=Prompt([run, "Summarize this run."]),
    metadata={"experiment": "v1", "category": "behavior-analysis"}
)
```


When the same ref appears multiple times, the first occurrence renders as full content alongside an alias, and subsequent occurrences render as just the alias.

```

### Adding Analysis Results to Context

You can include previous analysis results in your context:

```python
result = ResultRef(
    id="<result-uuid>",
    result_set_id="<result-set-uuid>",
    collection_id="<collection-uuid>"
)

request = LLMRequest(
    prompt=Prompt([result, "Summarize the findings from this analysis."])
)
```

### Structured Output

```python
result = client.submit_llm_requests(
    collection_id="<collection-uuid>",
    requests=[request],
    result_set_name="classification/v1",
    output_schema={
        "type": "object",
        "properties": {
            "category": {"type": "string", "enum": ["helpful", "harmful", "neutral"]},
            "confidence": {"type": "number"},
            "reasoning": {"type": "string", "citations": True} # for "explanation" fields like this, we usually want the LLM to cite pieces of the transcript we provide. citations = True is how we tell the LLM to include citations.
        },
        "required": ["category", "confidence", "reasoning"]
    }
)
```

## Writing a good prompt

The quality of LLM output depends on the quality the prompt you write for the LLMRequest. The LLM knows it is analyzing agent run transcripts, and knows how to cite items in its context. You can ask the LLM to cite items in its context and it will just work without further guidance.Otherwise, you are responsible for understanding the purpose of the LLMRequest and writing a clear prompt articulating what you want the LLM to do.

* Include any information about the runs that is not obvious from the transcripts but important for analyzing them appropriately
* How detailed or brief should output be? 1 sentence? 1 paragraph? more? Concise output has less detail but is easier to skim, and will consume fewer tokens if passed to another LLM
* If you're asking for extensive (multi-paragraph) analysis, how should the output be structured? Note: markdown is supported
* If you are looking for a particular behavior, how exactly is that behavior defined? See "Rubric Refinement" below.

## Rubric Refinement
When we use an LLM to judge an AI agent run transcript, we provide a rubric that specifies what we want to judge. For example, we may want to judge whether the agent cheated, or whether it considered multiple strategies, or whether it was excessively verbose. Some of these things are up to interpretation (how verbose is too verbose?) but a rubric must be clear and unambiguous.

Rubric refinement is the process of editing a rubric so that the LLM will produce accurate and useful results.

### Asking questions
When refining a rubric, you may use the AskUserQuestion tool to clarify any ambiguities about what the user is asking for.

- Make sure your questions are simple, self-contained, and only address one issue at a time.
- Do not assume that the user has read any of the transcripts; contextualize questions with sufficient detail.
- Ask questions one by one as if you are having a conversation with a user. Do NOT put them all in the same message.
- The user may have follow-up questions about specific details. Do your best to answer, and make your answers self-contained and comprehensive.


## Submitting Requests for Backend Processing

Use `submit_llm_requests()` to have the backend process your requests:

```python
result = client.submit_llm_requests(
    collection_id="<collection-uuid>",
    requests=[request1, request2, ...],
    model_string="openai/gpt-5-mini", # good to pass a model explicitly, use this one by default
    result_set_name="cheating/v1",  # hierarchical naming
    exists_ok=False  # Set True to append to existing result set
)

# Returns:
# {
#     "result_set_id": "<uuid>",
#     "job_id": "<uuid>",
#     "url": "https://docent.transluce.org/dashboard/.../results/..."
# }
```

Use hierarchical names with `/` separators for organization. It's often good to have a component like `v1`, `v2`, etc. so you can iterate on your methodology and compare results.

## Submitting Pre-Computed Results

If the language model you want to use is not available in Docent, you can compute the result within your script (using whatever LLM client library you want) and submit the final result to Docent so it shows up in the web UI. Example code:

```python
# Create results from local analysis
results = []
for run_id in agent_run_ids:
    run = AgentRunRef(id=run_id, collection_id=collection_id)

    request = LLMRequest(
        prompt=Prompt([run, "Analyze this run."]),
        metadata={"run_id": run_id}
    )

    # Run your local analysis (e.g., local LLM)
    output = my_local_llm_analysis(request)

    results.append(LLMResult(request=request, output=output))

# Upload to Docent
result = client.submit_results(
    collection_id="<collection-uuid>",
    results=results,
    result_set_name="local-analysis/v1",
    exists_ok=False  # Set True to append to existing result set
)

# Returns:
# {
#     "result_set_id": "<uuid>",
#     "url": "https://docent.transluce.org/dashboard/.../results/..."
# }
```

## Retrieving Results

```python
# Get result set metadata
result_set = client.get_result_set(collection_id, "analysis/experiment_1")

# Get results as DataFrame
df = client.get_result_set_dataframe(
    collection_id,
    "analysis/experiment_1",
    with_auto_joins=True  # Joins related data via _run_id/_result_id columns
)
# The dataframe returned by get_result_set_dataframe contains these columns:
# 'id', 'result_set_id', 'llm_context_spec', 'prompt_segments', 'user_metadata', 'output', 'error_json', 'input_tokens', 'output_tokens', 'model', 'created_at', 'cost_cents'

# List all result sets (optionally filtered by prefix)
sets = client.list_result_sets(collection_id, prefix="analysis/")
```

### Opening Results in Browser

Important: the browser is the preferred way to view results. Do not write code to retrieve results for presentation to the user, unless the user specifically requests. Do not wait for a request to finish to open the results. Use the `navigate_to` tool to open a docent URL in the browser.

## DQL (Docent Query Language)
Query agent runs, transcripts, and judge results using a read-only SQL subset. See `dql.md` for complete reference including:
- Available tables and columns
- JSON metadata access patterns
- Example queries
- Best practices and workarounds

### Executing DQL via the Python SDK

```python
from docent.sdk.client import Docent

client = Docent()
collection_id = "<collection-uuid>"

# (Optional) inspect available tables/columns
schema = client.get_dql_schema(collection_id)

# Execute a DQL query
result = client.execute_dql(
    collection_id,
    "SELECT agent_runs.id AS agent_run_id FROM agent_runs LIMIT 10",
)

# Convert to dict rows (or use result['columns'] + result['rows'] directly)
rows = client.dql_result_to_dicts(result)
```
