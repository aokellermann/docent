def main():
    print("Hello from tbench-analysis!")


if __name__ == "__main__":
    main()
